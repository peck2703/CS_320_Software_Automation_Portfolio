package main;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

public class AppointmentService {
	
	//Store a list of appointments in an array list
	private ArrayList<Appointment> appointmentList = new ArrayList<>();
	
	public void AddAppointment(String id, Date date, String description) {
		
		//Get current date to compare against parameter
		Date now = new Date();
		if(id.length() > 10 || id.length() == 0 || id == null) {
			throw new IllegalArgumentException("ID Length is incorrect");
		}
		if(date == null) {
			//parameter is before current date.
			throw new IllegalArgumentException("Date field is empty");
		}
		else if (date.before(now)) {
			throw new IllegalArgumentException("Date is before current date.");
		}
		if(description.length() > 50 || description.isEmpty() || description == null) {
			throw new IllegalArgumentException("Incorrect description length");
		}
		
		if(GetAppointmentByID(id) == null) {
			//No duplicate ID exists; create new appointment
			appointmentList.add(new Appointment(id, date, description));
		}
	}
	public void ChangeDate(String id, Date newDate) {
		
		//Create new date
		Date today = new Date();
		
		if(newDate != null && newDate.before(today)) {
			
			//Date is not null but before today
			throw new IllegalArgumentException("Date is before current date.");
		}
		else if(newDate != null && !newDate.before(today)) {
			
			//Date is not null and after current date. Change date
			GetAppointmentByID(id).setAppointmentDate(newDate);
		}
		else {
			//Date is likely null
			throw new IllegalArgumentException("Date is invalid.");
		}
	}
	public void ChangeDescription(String id, String newDescription) {
		if(newDescription.length() > 50 || newDescription.isEmpty() || newDescription == null) {
			//Invalid description change
			throw new IllegalArgumentException("New Description is invalid.");
		}
		else {
			GetAppointmentByID(id).setAppointmentDescription(newDescription);
		}
	}
	public Appointment GetAppointmentByID(String id) {
		
		Appointment testAppointment = null;
		
		//Create Iterator
		Iterator<Appointment> appointmentIterator = appointmentList.iterator();
		
		//While loop
		while(appointmentIterator.hasNext()) {
			testAppointment = appointmentIterator.next();
			if(id.equals(testAppointment.getAppointmentID())) {
				return testAppointment;
			}
		}
		//No such ID exists
		return null;
	}
}
