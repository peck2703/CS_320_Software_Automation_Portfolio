package main;

import java.util.ArrayList;
import java.util.Iterator;


public class TaskService {
	
	//Store list of tasks in arraylist
	private ArrayList<Task> taskList = new ArrayList<>();
	
	//Create iterator class to loop through
	Iterator<Task> taskIterator = taskList.iterator();
	
	public void AddTask(String id, String name, String description) {
		if(id.length() > 10 || id.length() == 0) {
			throw new IllegalArgumentException("ID length is incorrect.");
		}
		if(name.length() > 20 || name.length() == 0 || name == "") {
			throw new IllegalArgumentException("Name length is incorrect.");
		}
		if(description.length() > 50 || description.length() == 0 || description == "") {
			throw new IllegalArgumentException("Name length is incorrect.");
		}
		
		//Check if existing id exists
		if(!CheckExistingTaskID(id)) {
			taskList.add(new Task(id, name, description));
		}
	}
	public boolean CheckExistingTaskID(String id) {
		//Store a temporary boolean
		boolean idMatches = false;
		
		//While loop for iterator
		while(taskIterator.hasNext()) {
			if(id.equals(taskIterator.next().getId())) {
				idMatches = true;
				break;
			}
			else {
				idMatches = false;
			}
		}
		return idMatches;
	}
	public Task GetTaskByID(String id) {
		
		Task test = null;
		//While loop for iterator
		Iterator<Task> taskIterator = taskList.iterator();
		
		while(taskIterator.hasNext()) {
			test = taskIterator.next();
			if(id.equals(test.getId())) {
				return test;
			}
		}
		//none exists
		return null;
	}
	public void DeleteTask(String id) {
		taskList.remove(GetTaskByID(id));
	}
	public void ChangeName(String id, String name) {
		
		if (name == null || name.isEmpty() || name.length() > 10) {
	        throw new IllegalArgumentException("Name length is incorrect.");
	    }
		
		while(taskIterator.hasNext()) {
			Task updateTask = taskIterator.next();
			if(updateTask.getId().equals(id)) {
				updateTask.setName(name);
				return;
			}
		}
		// Handle the case where no contact with the given ID is found
	    throw new IllegalArgumentException("Contact with ID " + id + " not found.");
	}
	public void ChangeDescription(String id, String description) {
	
	if (description == null || description.isEmpty() || description.length() > 50) {
        throw new IllegalArgumentException("Description length is incorrect.");
    }
	
	while(taskIterator.hasNext()) {
		Task updateTask = taskIterator.next();
		if(updateTask.getId().equals(id)) {
			updateTask.setDescription(description);
			return;
		}
	}
	// Handle the case where no contact with the given ID is found
    throw new IllegalArgumentException("Contact with ID " + id + " not found.");
	}
}
