package main;

import java.util.Date;

public class Appointment {
	String appointmentID;
	Date appointmentDate;
	String appointmentDescription;
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getAppointmentDescription() {
		return appointmentDescription;
	}
	public void setAppointmentDescription(String appointmentDescription) {
		this.appointmentDescription = appointmentDescription;
	}
	public String getAppointmentID() {
		return appointmentID;
	}
	public Appointment(String id, Date date, String description) {
		this.appointmentID = id;
		this.appointmentDate = date;
		this.appointmentDescription = description;
	}
}
