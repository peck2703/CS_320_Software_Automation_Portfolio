package main;

import java.util.ArrayList;
import java.util.Iterator;

public class ContactService {
	
	//Store all contacts in dynamic array list
	private ArrayList<Contact> contactList = new ArrayList<>();
	
	//Create iterator class to loop through
	Iterator<Contact> ContactIterator = contactList.iterator();
	
	public void AddContact(String id, String firstName, String lastName, String phone, String address) {
		
		if(id.length() > 10 || id.length() == 0) {
			throw new IllegalArgumentException("ID length is incorrect.");
		}
		if (firstName.length() > 10 || firstName == "") {
			throw new IllegalArgumentException("First Name length is incorrect.");
		}
		if (lastName.length() > 10 || lastName == "") {
			throw new IllegalArgumentException("Last name length is incorrect.");
		}
		if(phone.length() != 10) {
			throw new IllegalArgumentException("Phone length is incorrect.");
		}
		if(address.length() > 30 ||address == "") {
			throw new IllegalArgumentException("Address length is incorrect.");
		}
		
		if(!CheckContactID(id)) {
			contactList.add(new Contact(id, firstName, lastName, phone, address));
		}
	}
	public void DeleteContact(String id) {
		
		while(ContactIterator.hasNext()) {
			Contact delContact = ContactIterator.next();
			if(delContact.getContactID().equals(id)) {
				ContactIterator.remove();
			}
		}
		System.out.println("Contact removed.");
	}
	public boolean CheckContactID(String id) {
		
		//Store a temporary boolean to return
		boolean idMatches = false;
		
		//Do a loop to see if ID exists
		while(ContactIterator.hasNext()) {
			if(id == ContactIterator.next().getContactID()) {
				idMatches = true;
				break;
			}
			else {
				idMatches = false;
			}
		}
		//Return match or not.
		return idMatches;
	}
	public void ChangeFirstName(String id, String name) {
		
		if (name == null || name.isEmpty() || name.length() > 10) {
	        throw new IllegalArgumentException("First name length is incorrect.");
	    }
		
		while(ContactIterator.hasNext()) {
			Contact updateContact = ContactIterator.next();
			if(updateContact.getContactID().equals(id)) {
				updateContact.setFirstName(name);
				return;
			}
		}
		// Handle the case where no contact with the given ID is found
	    throw new IllegalArgumentException("Contact with ID " + id + " not found.");
	}
	public void ChangeLastName(String id, String name) {
		
		while(ContactIterator.hasNext()) {
			Contact updateContact = ContactIterator.next();
			if(updateContact.getContactID().equals(id)) {
				updateContact.setLastName(name);;
			}
		}
		System.out.println("Last name changed.");
	}
	public void ChangePhone(String id, String phone) {
		
		while(ContactIterator.hasNext()) {
			Contact updateContact = ContactIterator.next();
			if(updateContact.getContactID().equals(id)) {
				updateContact.setPhoneNumber(phone);;
			}
		}
		System.out.println("Phone number changed.");
	}
	public void ChangeAddress(String id, String address) {
		
		while(ContactIterator.hasNext()) {
			Contact updateContact = ContactIterator.next();
			if(updateContact.getContactID().equals(id)) {
				updateContact.setAddress(address);;
			}
		}
		System.out.println("Phone number changed.");
	}
}