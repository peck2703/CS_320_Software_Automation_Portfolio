package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Iterator;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.BeforeEach;

class ContactServiceTest {

	//Store all contacts in dynamic array list
	private ArrayList<ContactTest> contactListTest = new ArrayList<>();
	
	//Create iterator class to loop through
	Iterator<ContactTest> ContactIteratorTest = contactListTest.iterator();
	
	//Setup tests before to test successful cases
	@BeforeEach
	@DisplayName("Setting up valid data")
    void setUp() {
        // Arrange: Create a fresh contact service and list for each test
        contactListTest = new ArrayList<>();

        // Populate the list with some test data
        contactListTest.add(new ContactTest("123", "John", "Doe", "1234567890", "1 Main St"));
        contactListTest.add(new ContactTest("456", "Jane", "Smith", "9876543210", "22 Oak Ave"));
    }
	
	@Test
	@DisplayName("Deleting Contact - Successful")
    void deleteContact_successfullyRemovesExistingContact() {
        // Arrange
        String idToDelete = "123";
        
        while(ContactIteratorTest.hasNext()) {
			ContactTest delContact = ContactIteratorTest.next();
			if(delContact.getContactID().equals(idToDelete)) {
				ContactIteratorTest.remove();
				
				// Assert: The list size has decreased by one, and the contact is no longer present
		        assertEquals(1, contactListTest.size());
			}
		}
    }
	
	@Test
	@DisplayName("Deleting Contact - Unsuccessful")
    void deleteContact_doesNothingForNonExistentContact() {
        // Arrange
        String nonExistentId = "999";
        int initialSize = contactListTest.size();

        while(ContactIteratorTest.hasNext()) {
			ContactTest delContact = ContactIteratorTest.next();
			if(delContact.getContactID().equals(nonExistentId)) {
				ContactIteratorTest.remove();
			}
		}
        
        // Assert: The list size remains unchanged
        assertEquals(initialSize, contactListTest.size());
    }
	
	@Test
	@DisplayName("Empty Contact List")
    void deleteContact_handlesEmptyListGracefully() {
        // Arrange: Start with an empty list
        contactListTest.clear();
        String anyId = "anyId";
        
        while(ContactIteratorTest.hasNext()) {
			ContactTest delContact = ContactIteratorTest.next();
			if(delContact.getContactID().equals(anyId)) {
				ContactIteratorTest.remove();
			}
		}
        
        assertEquals(0, contactListTest.size()); // The list is still empty
    }
	
	@DisplayName("Adding Contact")
	public void AddContact(String id, String firstName, String lastName, String phone, String address) {
		
		if (id.length() > 10) {
            throw new IllegalArgumentException("ID length is incorrect.");
        }
        if (firstName == null || firstName.length() > 10 || firstName.isEmpty()) {
            throw new IllegalArgumentException("First Name length is incorrect.");
        }
        if (lastName == null || lastName.length() > 10 || lastName.isEmpty()) {
            throw new IllegalArgumentException("Last name length is incorrect.");
        }
        if (phone == null || phone.length() != 10) {
            throw new IllegalArgumentException("Phone length is incorrect.");
        }
        if (address == null || address.length() > 30 || address.isEmpty()) {
            throw new IllegalArgumentException("Address length is incorrect.");
        }
	}
	
	@Test
	@DisplayName("Invalid ID Length")
    void testAddContact_invalidIdLength_throwsException() {
        // Use assertThrows to test that a long ID throws the expected exception.
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
        AddContact("12345678901", "John", "Doe", "1234567890", "123 Main St"));
    }

    @Test
    @DisplayName("Long First Name")
    void testAddContact_invalidFirstNameLength_throwsException() {
        // Test a first name that is too long.
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
        AddContact("123", "TooLongFirstName", "Doe", "1234567890", "123 Main St"));
    }

    @Test
    @DisplayName("Null First Name")
    void testAddContact_emptyFirstName_throwsException() {
        // Test an empty first name. 
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
        AddContact("123", "", "Doe", "1234567890", "123 Main St"));
    }

    @Test
    @DisplayName("Long Last Name")
    void testAddContact_invalidLastNameLength_throwsException() {
        // Test a last name that is too long.
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
        AddContact("123", "John", "TooLongLastName", "1234567890", "123 Main St"));
    }
    
    @Test
    @DisplayName("Null Last Name")
    void testAddContact_emptyLastName_throwsException() {
        // Test an empty last name.
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
        AddContact("123", "John", "", "1234567890", "123 Main St"));
    }

    @Test
    @DisplayName("Invalid Phone Length")
    void testAddContact_invalidPhoneLength_throwsException() {
        // Test a phone number with an incorrect length.
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
        AddContact("123", "John", "Doe", "12345", "123 Main St"));
    }

    @Test
    @DisplayName("Long Address")
    void testAddContact_invalidAddressLength_throwsException() {
        // Test an address that is too long.
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
        AddContact("123", "John", "Doe", "1234567890", "This address is definitely way too long for validation"));
    }

    @Test
    @DisplayName("Null Address")
    void testAddContact_emptyAddress_throwsException() {
        // Test an empty address.
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
        AddContact("123", "John", "Doe", "1234567890", ""));
    }
    
    @Test
    @DisplayName("Change First Name - Valid")
    void testChangeFirstName_validChange_updatesContact() {

        String contactId = "123";
        String newName = "Jonathan";
        
        ContactTest updateContact = null;
        while(ContactIteratorTest.hasNext()) {
        	updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				updateContact.setLastName(newName);
				
				assertNotNull(updateContact);
		        assertEquals(newName, updateContact.getLastName());
			}
		}
    }

    @Test
    @DisplayName("Change name - Invalid (Too long)")
    void testChangeFirstName_invalidNameTooLong_throwsException() {
        
        String contactId = "123";
        String invalidName = "ThisIsTooLong";

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setFirstName(invalidName));
			}
        }
    }
    
    @Test
    @DisplayName("Change name - Invalid (Empty)")
    void testChangeFirstName_invalidNameEmpty_throwsException() {
        
        String contactId = "123";
        String invalidName = "ThisIsTooLong";

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setFirstName(invalidName));
			}
        }
    }

    @Test
    void testChangeFirstName_invalidNameNull_throwsException() {
        
        String contactId = "123";
        String invalidName = null;

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setFirstName(invalidName));
			}
        }
    }

    @Test
    void testChangeFirstName_nonExistentId_throwsException() {
        
        String nonExistentId = "999";
        String newName = "TestName";

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(nonExistentId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setFirstName(newName));
			}
        }
    }
    @Test
    @DisplayName("Change Last Name - Valid")
    void testChangeLastName_validChange_updatesContact() {

        String contactId = "123";
        String newName = "Jonathan";
        
        ContactTest updateContact = null;
        while(ContactIteratorTest.hasNext()) {
        	updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				updateContact.setLastName(newName);
				
				assertNotNull(updateContact);
		        assertEquals(newName, updateContact.getLastName());
			}
		}
    }

    @Test
    @DisplayName("Change name - Invalid (Too long)")
    void testChangeLastName_invalidNameTooLong_throwsException() {
        
        String contactId = "123";
        String invalidName = "ThisIsTooLong";

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setLastName(invalidName));
			}
        }
    }
    
    @Test
    @DisplayName("Change name - Invalid (Empty)")
    void testChangeLastName_invalidNameEmpty_throwsException() {
        
        String contactId = "123";
        String invalidName = "ThisIsTooLong";

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setLastName(invalidName));
			}
        }
    }

    @Test
    void testChangeLastName_invalidNameNull_throwsException() {
        
        String contactId = "123";
        String invalidName = null;

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setLastName(invalidName));
			}
        }
    }

    @Test
    void testChangeLastName_nonExistentId_throwsException() {
        
        String nonExistentId = "999";
        String newName = "TestName";

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(nonExistentId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setLastName(newName));
			}
        }
    }
    @Test
    @DisplayName("Change Phone - Valid")
    void testChangePhoneName_validChange_updatesContact() {

        String contactId = "123";
        String newNumber = "9781234567";
        
        ContactTest updateContact = null;
        while(ContactIteratorTest.hasNext()) {
        	updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				updateContact.setPhoneNumber(newNumber);
				
				assertNotNull(updateContact);
		        assertEquals(newNumber, updateContact.getPhoneNumber());
			}
		}
    }

    @Test
    @DisplayName("Change phone - Invalid (Too long)")
    void testChangePhoneName_invalidNameTooLong_throwsException() {
        
        String contactId = "123";
        String newNumber = "97812345678";

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setPhoneNumber(newNumber));
			}
        }
    }
    
    @Test
    @DisplayName("Change name - Invalid (Empty)")
    void testChangePhoneName_invalidNameEmpty_throwsException() {
        
        String contactId = "123";
        String newNumber = "";

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setPhoneNumber(newNumber));
			}
        }
    }

    @Test
    @DisplayName("Change phone - Invalid (Null)")
    void testChangePhoneName_invalidNameNull_throwsException() {
        
        String contactId = "123";
        String newNumber = null;

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setPhoneNumber(newNumber));
			}
        }
    }

    @Test
    @DisplayName("Change phone - Invalid (Invalid ID)")
    void testChangePhoneName_nonExistentId_throwsException() {
        
        String nonExistentId = "999";
        String newNumber = "1234567890";

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(nonExistentId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setPhoneNumber(newNumber));
			}
        }
    }
    @Test
    @DisplayName("Change Address Name - Valid")
    void testChangeAddressName_validChange_updatesContact() {

        String contactId = "123";
        String newAddress = "555 Main St, Anytown, USA";
        
        ContactTest updateContact = null;
        while(ContactIteratorTest.hasNext()) {
        	updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				updateContact.setAddress(newAddress);
				
				assertNotNull(updateContact);
		        assertEquals(newAddress, updateContact.getAddress());
			}
		}
    }

    @Test
    @DisplayName("Change name - Invalid (Too long)")
    void testChangeAddressName_invalidNameTooLong_throwsException() {
        
        String contactId = "123";
        String newAddress = "PO Box 123, Nowhere, AZ - PO Box 123, Nowhere, AZ";

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setAddress(newAddress));
			}
        }
    }
    
    @Test
    @DisplayName("Change name - Invalid (Empty)")
    void testChangeAddressName_invalidNameEmpty_throwsException() {
        
        String contactId = "123";
        String newAddress = "";

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setAddress(newAddress));
			}
        }
    }

    @Test
    void testChangeAddressName_invalidNameNull_throwsException() {
        
        String contactId = "123";
        String newAddress = null;

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(contactId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setAddress(newAddress));
			}
        }
    }

    @Test
    void testChangeAddressName_nonExistentId_throwsException() {
        
        String nonExistentId = "999";
        String newAddress = "TestName";

        while(ContactIteratorTest.hasNext()) {
			ContactTest updateContact = ContactIteratorTest.next();
			if(updateContact.getContactID().equals(nonExistentId)) {
				IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> updateContact.setAddress(newAddress));
			}
        }
    }
}