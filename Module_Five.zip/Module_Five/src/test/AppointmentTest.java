package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}
	
	String appointmentID;
	Date appointmentDate;
	String appointmentDescription;
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getAppointmentDescription() {
		return appointmentDescription;
	}
	public void setAppointmentDescription(String appointmentDescription) {
		this.appointmentDescription = appointmentDescription;
	}
	public String getAppointmentID() {
		return appointmentID;
	}
	public AppointmentTest(String id, Date date, String description) {
		this.appointmentID = id;
		this.appointmentDate = date;
		this.appointmentDescription = description;
	}
}
