package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Iterator;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.*;

class TaskServiceTest {
	
	//Store list of tasks in arraylist
	private ArrayList<TaskTest> taskList = new ArrayList<>();
		
	//Create iterator class to loop through
	//Iterator<TaskTest> taskIterator = taskList.iterator();

	public void AddTask(String id, String name, String description) {
		if(id.length() > 10 || id.length() == 0 || id == null) {
			throw new IllegalArgumentException("ID length is incorrect.");
		}
		if(name.length() > 20 || name.length() == 0 || name == "" || name == null) {
			throw new IllegalArgumentException("Name length is incorrect.");
		}
		if(description.length() > 50 || description.length() == 0 || description == "" || description == null) {
			throw new IllegalArgumentException("Name length is incorrect.");
		}
		
		//Check if existing id exists
		if(!CheckExistingTaskID(id)) {
			taskList.add(new TaskTest(id, name, description));
		}
	}
	public TaskTest GetTaskByID(String id) {
		
		TaskTest test = null;
		//While loop for iterator
		Iterator<TaskTest> taskIterator = taskList.iterator();
		
		while(taskIterator.hasNext()) {
			test = taskIterator.next();
			if(id.equals(test.getId())) {
				return test;
			}
		}
		//none exists
		return null;
	}
	public void DeleteTask(String id) {
		taskList.remove(GetTaskByID(id));
	}
	public boolean CheckExistingTaskID(String id) {
		//re-instantiate the iterator
		Iterator<TaskTest> taskIterator = taskList.iterator();
		
		//Store a temporary boolean
		boolean idMatches = false;
		
		//While loop for iterator
		while(taskIterator.hasNext()) {
			if(id.equals(taskIterator.next().getId())) {
				idMatches = true;
				break;
			}
			else {
				idMatches = false;
			}
		}
		return idMatches;
	}
	public void ChangeName(String id, String name) {
		
		Iterator<TaskTest> taskIterator = taskList.iterator();
		
		if (name == null || name.isEmpty() || name.length() > 10) {
	        throw new IllegalArgumentException("Name length is incorrect.");
	    }
		
		while(taskIterator.hasNext()) {
			TaskTest updateTask = taskIterator.next();
			if(updateTask.getId().equals(id)) {
				updateTask.setName(name);
				return;
			}
		}
		// Handle the case where no contact with the given ID is found
	    throw new IllegalArgumentException("Contact with ID " + id + " not found.");
	}
	public void ChangeDescription(String id, String description) {
	
	if (description == null || description.isEmpty() || description.length() > 50) {
        throw new IllegalArgumentException("Description length is incorrect.");
    }
	Iterator<TaskTest> taskIterator = taskList.iterator();
	while(taskIterator.hasNext()) {
		TaskTest updateTask = taskIterator.next();
		if(updateTask.getId().equals(id)) {
			updateTask.setDescription(description);
			return;
		}
	}
	// Handle the case where no contact with the given ID is found
    throw new IllegalArgumentException("Contact with ID " + id + " not found.");
	}
	
	@BeforeEach
	@DisplayName("Setting up Valid Data")
	void setUp() {
		taskList.add(new TaskTest("035789", "ProcExit", "Exits the current process"));
		taskList.add(new TaskTest("3578921", "Null.exe", "Null process occuring"));
	}
	@Test
	@DisplayName("Adding Task successfully")
    void testAddTask_ValidTask_AddsSuccessfully() {
        AddTask("12345", "New Task", "Description for new task");
        assertTrue(CheckExistingTaskID("12345"), "Task should be added and found");
    }
	@Test
	@DisplayName("Duplicating Task unsuccessfully")
    void testAddTask_TaskWithExistingId_DoesNotAddDuplicate() {
        AddTask("12345", "Original Task", "Original description");
        AddTask("12345", "Duplicate Task", "Duplicate description");
    }
	@Test
	@DisplayName("Add task - invalid id length - unsuccessfully")
    void testAddTask_InvalidIdLength_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            AddTask("12345678901", "Short Name", "Short Description"); // ID too long
        });
        assertThrows(IllegalArgumentException.class, () -> {
            AddTask("", "Short Name", "Short Description"); // Empty ID
        });
    }
	@Test
	@DisplayName("Add task - invalid name length - unsuccessfully")
    void testAddTask_InvalidNameLength_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            AddTask("1", "This is a name that is way too long for the field", "Short Description"); // Name too long
        });
        assertThrows(IllegalArgumentException.class, () -> {
            AddTask("1", "", "Short Description"); // Empty name
        });
    }
	@Test
	@DisplayName("Add task - invalid description length - unsuccessfully")
    void testAddTask_InvalidDescriptionLength_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            AddTask("1", "Short Name", "This is a description that is way too long for the field. This should cause an error."); // Description too long
        });
        assertThrows(IllegalArgumentException.class, () -> {
            AddTask("1", "Short Name", ""); // Empty description
        });
    }
	@Test
	@DisplayName("Check existing ID - successful")
    void testCheckExistingTaskID_IdExists_ReturnsTrue() {
		
		//Adding valid data to test
        AddTask("uniqueId", "Task Name", "Task Description");
        assertTrue(CheckExistingTaskID("uniqueId"));
    }
	@Test
	@DisplayName("Check existing ID - successful")
    void testCheckExistingTaskID_IdDoesNotExist_ReturnsFalse() {
		
		//Adding invalid data to test
        AddTask("uniqueId", "Task Name", "Task Description");
        assertFalse(CheckExistingTaskID("nonExistentId"));
    }
	@Test
	@DisplayName("Check existing ID - unsuccessful")
    void testCheckExistingTaskID_WithEmptyService_ReturnsFalse() {
        assertFalse(CheckExistingTaskID("anyId"));
    }
	@Test
	@DisplayName("Change name - unsuccessful")
    void testChangeName_ExistingId_NameIsUpdated() {
        String id = "123";
        AddTask(id, "Original Name", "Original Description");
        
        String newName = "New name";
        ChangeName(id, newName);
        
        //Check it exists
        TaskTest updateTest = GetTaskByID(id);
        
        assertNotNull(updateTest, "Task shall not be null after updating.");
        assertEquals(newName, updateTest.getName());
		}
	@Test
	@DisplayName("Change name - unsuccessful")
    void testChangeName_InvalidId_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            ChangeName("nonExistentId", "Some Name");
        });
    }
	@Test
	@DisplayName("Change name - unsuccessful - Invalid")
    void testChangeName_InvalidName_ThrowsException() {
        String id = "123";
        AddTask(id, "Original Name", "Original Description");
        
        assertThrows(IllegalArgumentException.class, () -> {
        	ChangeName(id, null); // Null name
        });
        assertThrows(IllegalArgumentException.class, () -> {
            ChangeName(id, ""); // Empty name
        });
        assertThrows(IllegalArgumentException.class, () -> {
            ChangeName(id, "This is a name that is too long"); // Name too long
        });
    }
	@Test
	@DisplayName("Change description - unsuccessful - Invalid")
    void testChangeDescription_ExistingId_DescriptionIsUpdated() {
        String id = "123";
        AddTask(id, "Name", "Original Description");
        ChangeDescription(id, "New Description");
    }
	@Test
	@DisplayName("Change description - unsuccessful - Invalid")
    void testChangeDescription_InvalidId_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            ChangeDescription("nonExistentId", "Some Description");
        });
    }
	@Test
	@DisplayName("Change description - unsuccessful - Invalid")
    void testChangeDescription_InvalidDescription_ThrowsException() {
        String id = "123";
        AddTask(id, "Name", "Original Description");
        
        assertThrows(IllegalArgumentException.class, () -> {
            ChangeDescription(id, null); // Null description
        });
        assertThrows(IllegalArgumentException.class, () -> {
            ChangeDescription(id, ""); // Empty description
        });
        assertThrows(IllegalArgumentException.class, () -> {
            ChangeDescription(id, "This is a description that is way too long for the field, well over 50 characters."); // Description too long
        });
    }
	@Test
	@DisplayName("Get existing task by ID - returns correct task")
	void testGetTaskByID_IdExists_ReturnsCorrectTask() {
	    // Add a specific task to the list using the `AddTask` method.
	    String id = "task001";
	    String name = "Test Task";
	    String description = "Description for test task";
	    AddTask(id, name, description);

	    // Retrieve the task using the newly added method.
	    TaskTest retrievedTask = GetTaskByID(id);

	    // Assert that the retrieved task is not null and has the correct properties.
	    assertNotNull(retrievedTask, "Retrieved task should not be null.");
	    assertEquals(id, retrievedTask.getId(), "Retrieved task ID should match.");
	    assertEquals(name, retrievedTask.getName(), "Retrieved task name should match.");
	    assertEquals(description, retrievedTask.getDescription(), "Retrieved task description should match.");
	}
	@Test
	@DisplayName("Get non-existent task by ID - returns null")
	void testGetTaskByID_IdDoesNotExist_ReturnsNull() {
	    // Attempt to retrieve a task with an ID that is not in the list.
	    TaskTest retrievedTask = GetTaskByID("nonExistentId");

	    // Assert that the method returns null for a non-existent ID.
	    assertNull(retrievedTask, "Method should return null for non-existent IDs.");
	}
	@Test
	@DisplayName("Delete task - existing ID - successful")
	void testDeleteTask_ExistingId_RemovesTask() {
	    // Add a specific task that will be deleted.
	    String idToDelete = "taskToDel";
	    AddTask(idToDelete, "Delete", "Description for task to delete");

	    // Assert that the task exists before deletion.
	    assertTrue(CheckExistingTaskID(idToDelete), "Task should exist before deletion.");
	    
	    // Call the DeleteTask method.
	    DeleteTask(idToDelete);
	    
	    // Assert that the task no longer exists.
	    assertFalse(CheckExistingTaskID(idToDelete), "Task should not exist after deletion.");
	    
	    // Also, verify that the other initial tasks from setUp are still there.
	    assertTrue(CheckExistingTaskID("035789"), "Initial task '035789' should still exist.");
	    assertTrue(CheckExistingTaskID("3578921"), "Initial task '3578921' should still exist.");
	}
	@Test
	@DisplayName("Delete task - non-existent ID - no change")
	void testDeleteTask_NonExistentId_DoesNotChangeList() {
	    // Get the initial size of the task list after the @BeforeEach setup.
	    int initialSize = taskList.size();

	    // Call the DeleteTask method with a non-existent ID.
	    DeleteTask("nonExistentId");
	    
	    // Assert that the size of the list has not changed.
	    assertEquals(initialSize, taskList.size(), "List size should not change when deleting a non-existent task.");
	}
}