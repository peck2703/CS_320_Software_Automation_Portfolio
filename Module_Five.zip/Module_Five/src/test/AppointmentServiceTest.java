package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


class AppointmentServiceTest {

		@BeforeAll
		static void setUpBeforeClass() throws Exception {
		}
	
		@SuppressWarnings("deprecation")
		@BeforeEach
		@DisplayName("Setting up initial values")
		void setUp() throws Exception {
			appointmentList = new ArrayList<>();
			//Creating 2 valid test data objects
			AddAppointment("A101", new Date(126, 11, 11), "This is a test class for a description");
	        AddAppointment("B202", new Date(126, 11, 18), "This is a second test class for a description");
		}
		
		@AfterEach
		@DisplayName("Clearing list")
	    void clearList() {
	        appointmentList.clear();
	    }

		//Store a list of appointments in an array list
		private ArrayList<AppointmentTest> appointmentList;
		
		public void AddAppointment(String id, Date date, String description) {
			
			//Get current date to compare against parameter
			Date now = new Date();
			if(GetAppointmentByID(id) == null) {
				if(id == null || id.isEmpty() || id.length() > 10) {
					throw new IllegalArgumentException("ID Length is incorrect");
				}
				if(date == null) {
					//parameter is before current date.
					throw new IllegalArgumentException("Date field is empty");
				}
				else if (date.before(now)) {
					throw new IllegalArgumentException("Date is before current date.");
				}
				if(description == null || description.isEmpty() || description.length() > 50) {
					throw new IllegalArgumentException("Incorrect description length");
				}
				
				//No duplicate ID exists; create new appointment
				appointmentList.add(new AppointmentTest(id, date, description));
			}
		}
		public void ChangeDate(String id, Date newDate) {
			
			//Create new date
			Date today = new Date();
			
			//Null check for appointment class
			AppointmentTest appointmentTest = GetAppointmentByID(id);
			
			if(appointmentTest == null) {
				//Id not found
				throw new IllegalArgumentException("Appointment with id " + " does not exist");
			}
			if(newDate != null && newDate.before(today)) {
				
				//Date is not null but before today
				throw new IllegalArgumentException("Date is before current date.");
			}
			else if(newDate != null && !newDate.before(today)) {
				
				//Date is not null and after current date. Change date
				GetAppointmentByID(id).setAppointmentDate(newDate);
			}
			else {
				//Date is likely null
				throw new IllegalArgumentException("Date is invalid.");
			}
		}
		public void ChangeDescription(String id, String newDescription) {
			
			//Null check for appointment class
			AppointmentTest appointmentTest = GetAppointmentByID(id);
			
			if(appointmentTest == null) {
				//Id not found
				throw new IllegalArgumentException("Appointment with id " + " does not exist");
			}
			
			if(newDescription == null || newDescription.isEmpty() || newDescription.length() > 50) {
				//Invalid description change
				throw new IllegalArgumentException("New Description is invalid.");
			}
			else {
				GetAppointmentByID(id).setAppointmentDescription(newDescription);
			}
		}
		public AppointmentTest GetAppointmentByID(String id) {
			
			AppointmentTest testAppointment = null;
			
			//Create Iterator
			Iterator<AppointmentTest> appointmentIterator = appointmentList.iterator();
			
			//While loop
			while(appointmentIterator.hasNext()) {
				testAppointment = appointmentIterator.next();
				if(id.equals(testAppointment.getAppointmentID())) {
					return testAppointment;
				}
			}
			//No such ID exists
			//throw new NullPointerException();
			return null;
		}
		@SuppressWarnings("deprecation")
		@Test
		@DisplayName("Adding Appointment - Successfully")
		void testAddAppointment_ValidAppointment_AddSuccessfully() {
			String newID = "C303";
			String newDescription = "This is a test";
			
			AddAppointment(newID, new Date(131, 11, 2020), newDescription);
			
			assertNotNull(GetAppointmentByID(newID), "Appointment should be found and not null");
		}
		@SuppressWarnings("deprecation")
		@Test
		@DisplayName("Adding Appointment - Unsuccessfully - Null ID")
	    void testAddAppointment_NullId_ThrowsException() {
	        assertThrows(NullPointerException.class, () ->
	            AddAppointment(null, new Date(9, 11, 2020), "Valid description"),
	            "Should throw exception for null ID."
	        );
	    }
		@SuppressWarnings("deprecation")
	    @Test
	    @DisplayName("Adding Appointment - Unsuccessfully - empty ID")
	    void testAddAppointment_EmptyId_ThrowsException() {
	        assertThrows(IllegalArgumentException.class, () ->
	            AddAppointment("", new Date(9, 11, 2020), "Valid description"),
	            "Should throw exception for empty ID."
	        );
	    }
		@SuppressWarnings("deprecation")
		@Test
		@DisplayName("Adding Appointment - Unsuccessfully - long ID")
	    void testAddAppointment_LongId_ThrowsException() {
	        assertThrows(IllegalArgumentException.class, () ->
	            AddAppointment("C3030303030303", new Date(9, 11, 2020), "Valid description"),
	            "Should throw exception for ID longer than 10 characters."
	        );
	    }
		@Test
		@DisplayName("Adding Appointment - Unsuccessfully - null date")
	    void testAddAppointment_NullDate_ThrowsException() {
	        assertThrows(IllegalArgumentException.class, () ->
	            AddAppointment("APP02", null, "Valid description"),
	            "Should throw exception for null date."
	        );
	    }
		@Test
		@DisplayName("Adding Appointment - Unsuccessfully - past date")
	    void testAddAppointment_PastDate_ThrowsException() {
	        // Arrange with a date far in the past
	        Date pastDate = new Date(System.currentTimeMillis() - 100000000);

	        assertThrows(IllegalArgumentException.class, () ->
	            AddAppointment("APP03", pastDate, "Valid description"),
	            "Should throw exception for past date."
	        );
	    }
		@SuppressWarnings("deprecation")
		@Test
		@DisplayName("Adding Appointment - Unsuccessfully - null description")
	    void testAddAppointment_NullDescription_ThrowsException() {
	        assertThrows(IllegalArgumentException.class, () ->
	            AddAppointment("APP04", new Date(9, 11, 2020), null),
	            "Should throw exception for null description."
	        );
	    }
		@SuppressWarnings("deprecation")
		@Test
		@DisplayName("Adding Appointment - Unsuccessfully - empty description")
	    void testAddAppointment_EmptyDescription_ThrowsException() {
	        assertThrows(IllegalArgumentException.class, () ->
	            AddAppointment("APP05", new Date(9, 11, 2020), ""),
	            "Should throw exception for empty description."
	        );
	    }
		@SuppressWarnings("deprecation")
		@Test
		@DisplayName("Adding Appointment - Unsuccessfully - long description")
	    void testAddAppointment_LongDescription_ThrowsException() {
	        String longDesc = "adsdfkasdfkasdkjsdkfasdlkfjasdkfjaksldjfksladfjskdlfjasdflksadfkljsdfljk";

	        assertThrows(IllegalArgumentException.class, () ->
	            AddAppointment("APP06", new Date(9, 11, 2020), longDesc),
	            "Should throw exception for description longer than 50 characters."
	        );
	    }
		@Test
		@DisplayName("Changing Date - Successfully")
	    void testChangeDate_ValidFutureDate_ChangesSuccessfully() {
	        // Arrange
	        Date newFutureDate = new Date(System.currentTimeMillis() + 200000000);
	        
	        //Grab an existing one from BeforeEach
	        String getExistingID = "A101";
	        
	        // Act
	        ChangeDate(getExistingID, newFutureDate);

	        // Assert
	        // Retrieve the updated appointment and verify the new date
	        AppointmentTest updatedAppointment = GetAppointmentByID(getExistingID);
	        assertNotNull(updatedAppointment, "Appointment should exist.");
	        assertEquals(newFutureDate, updatedAppointment.getAppointmentDate(), "Appointment date should be updated.");
	    }
		@Test
		@DisplayName("Changing Date - Unsuccessfully - Past date")
	    void testChangeDate_PastDate_ThrowsException() {
	        // Arrange
	        Date pastDate = new Date(System.currentTimeMillis() - 100000000);

	        // Act & Assert
	        assertThrows(IllegalArgumentException.class, () ->
	            ChangeDate("B202", pastDate),
	            "Should throw exception for a past date."
	        );
	    }
		@Test
		@DisplayName("Changing Date - Unsuccessfully - Null date")
	    void testChangeDate_NullDate_ThrowsException() {
	        // Act & Assert
	        assertThrows(IllegalArgumentException.class, () ->
	            ChangeDate("B202", null),
	            "Should throw exception for a null date."
	        );
	    }
		@Test
		@DisplayName("Changing Date - Unsuccessfully - nonExistent date")
	    void testChangeDate_NonExistentId_ThrowsException() {
	        // Arrange with a non-existent ID
	        Date newFutureDate = new Date(System.currentTimeMillis() + 200000000);
	        String nonExistentID = "B002451";

	        //GetAppointmentByID will return null, which will return an exception
	        assertThrows(IllegalArgumentException.class, () ->
	            ChangeDate(nonExistentID, newFutureDate),
	            "Should throw an exception for a non-existent ID."
	        );
	    }
		@Test
		@DisplayName("Changing Date - Unsuccessfully - Non-existant ID")
	    void testChangeDate_NonExistentId_GetAppointmentByIDReturnsNull() {

			String nonExistentID = "B002451";
			
	        assertNull(GetAppointmentByID(nonExistentID), "GetAppointmentByID should return null for a non-existent ID.");
	    }
		@Test
		@DisplayName("Changing Description - Successfully")
	    void testChangeDescription_ValidDescription_ChangesSuccessfully() {
	        	        
	        //Grab an existing one from BeforeEach
	        String getExistingID = "A101";
	        String newDescription = "This is a new description";
	        
	        //Change the description
	        ChangeDescription(getExistingID, newDescription);
	        
	        // Retrieve the updated appointment and verify the new date
	        AppointmentTest updatedAppointment = GetAppointmentByID(getExistingID);
	        assertNotNull(updatedAppointment, "Appointment should exist.");
	        assertEquals(newDescription, updatedAppointment.getAppointmentDescription(), "Appointment date should be updated.");
	    }
		@Test
		@DisplayName("Changing Description - Unsuccessfully - Empty")
	    void testChangeDescription_EmptyDescription_ChangesUnsuccessfully() {
	        	
			//Grab an existing ID from BeforeEach
			String existingAppointmentId = "A101";
			
			assertThrows(IllegalArgumentException.class, () ->
            ChangeDescription(existingAppointmentId, ""),
            "Should throw exception for an empty description."
					);
		}
		@Test
		@DisplayName("Changing Description - Unsuccessfully")
	    void testChangeDescription_NonExistentId_ThrowsException() {
	        
			String nonExistentId = "Error404";
			
	        assertThrows(IllegalArgumentException.class, () ->
	            ChangeDescription(nonExistentId, "Valid description"),
	            "Should throw exception for a non-existent ID."
	        );
	    }
		@Test
		@DisplayName("Changing Description - Unsuccessfully - Null description")
	    void testChangeDescription_NullDescription_ThrowsException() {
			
			//Grab an existing ID from BeforeEach
			String existingAppointmentId = "A101";
			
	        assertThrows(IllegalArgumentException.class, () ->
	            ChangeDescription(existingAppointmentId, null),
	            "Should throw exception for a null description."
	        );
	    }
		@Test
	    void testChangeDescription_LongDescription_ThrowsException() {
			
			//Grab an existing ID from BeforeEach
			String existingAppointmentId = "A101";

	        String longDescription = "a".repeat(51); // Creates a string with 51 'a' characters

	        // Act & Assert
	        assertThrows(IllegalArgumentException.class, () ->
	            ChangeDescription(existingAppointmentId, longDescription),
	            "Should throw exception for a description longer than 50 characters."
	        );
	    }
}
